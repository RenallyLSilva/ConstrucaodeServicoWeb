package com.exemplo.doisApis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DoisApisApplicationTests {

	@Test
	void contextLoads() {
	}

}
