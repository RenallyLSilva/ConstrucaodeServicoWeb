package com.exemplo.doisApis.api1;

import com.exemplo.doisApis.api1.Fip;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FipRepository extends JpaRepository<Fip, Long> {
}
