package com.exemplo.doisApis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DoisApisApplication {

	public static void main(String[] args) {
		SpringApplication.run(DoisApisApplication.class, args);
	}

}
